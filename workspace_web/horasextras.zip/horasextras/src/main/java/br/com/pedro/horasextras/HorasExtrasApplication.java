package br.com.pedro.horasextras;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HorasExtrasApplication {

	public static void main(String[] args) {
		SpringApplication.run(HorasExtrasApplication.class, args);
	}

}
